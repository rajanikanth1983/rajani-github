#!/bin/bash



for i in `cat inputFiles/tomcat.input`
do

        HOST=`echo $i | awk -F= '{print $2}' `
#        VERSION=`echo $i | awk -F, '{print $2}'`


        login=`ssh -o PasswordAuthentication=no $HOST pwd exit`


        if [[ "$login" = /home/wsuser ]]
        then


                       echo "Working on .....$HOST "
                       scp  /ebiz/work/installSignerCerts/bin/certs/uhg_issuing_ca3_new $HOST:/wastmp/uhg_issuing_ca3_new >/dev/null 2>&1
                       scp  /ebiz/work/installSignerCerts/bin/tomcat_runinstall.sh $HOST:/wastmp/tomcat_runinstall.sh  >/dev/null 2>&1
                       ssh $HOST " chmod 750 /wastmp/tomcat_runinstall.sh ; /wastmp/tomcat_runinstall.sh ; rm -f /wastmp/tomcat_runinstall.sh " >> tomcat_certs.log 2>/dev/null 
                   
         else
           echo "$HOST,NON_REACHABLE" >> tomcat_certs.log
        fi


done 2>/dev/null

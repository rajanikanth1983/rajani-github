#!/bin/bash



for i in `cat inputFiles/jboss.input`
do

        HOST=`echo $i | awk -F, '{print $1}'`
#        VERSION=`echo $i | awk -F, '{print $2}'`


        login=`ssh -o PasswordAuthentication=no $HOST pwd exit`


        if [[ "$login" = /home/wsuser ]]
        then


                       echo "Working on .....$HOST "
                       scp  /ebiz/work/installSignerCerts/bin/eap_custom.sh $HOST:/wastmp/eap_custom.sh  >/dev/null 2>&1
                       ssh $HOST "chmod 750 /wastmp/eap_custom.sh ; /wastmp/eap_custom.sh ; rm -f /wastmp/eap_custom.sh " >> jboss_custom_store.list  2>/dev/null
                   
         else
           echo "$HOST,NON_REACHABLE" >> jboss_custom_store.list
        fi


done 2>/dev/null

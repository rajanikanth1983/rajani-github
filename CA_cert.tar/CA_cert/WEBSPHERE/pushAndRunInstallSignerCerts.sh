#!/bin/ksh

function Usage {
echo "Sets the WebSphere Console's LDAP Admin id and pw.
Usage:  pushAndRunChgAdminId.sh -h <host(s) list or file name> [-m <app mui>] [-s] [-l <log file>]
  -i   Required: Input file. This can contain the values for <host list>, WAS <environment>, Old and New passwords.
  -l   Optional: Log file. Default log file: /home/wsuser/webapp/work/chgKeyStorePws/logs/pushAndRunChgKeyStorePws-<timestamp>.log
  Example: pushAndRunChgAdminId.sh -i /home/wsuser/webapp/work/chgKeyStorePws/inputFiles/ebz-apsrd0311.input
     The input file lines should have the form:
     ENV=<ebiz env> HOSTS=<hostname> OLDPWD=<old password> NEWPWD=<new password>
     The password values are option, and without them the script will ask the user for them.      
  "
  exit $1
}

# We have this because there might be some hosts where we have to chg the remote directory ... like because if the first one is full
function setRemoteDirectory {
  rDir=$1
  # this is the dir on the target server where we will place things
  remoteDir=$rDir
  # these 2 are the scripts that we need to run on the target server.
  runScript1="${remoteDir}/runInstallSignerCerts.sh"
  # this is the other script, that is also run on the target server, but via the other scripts listed above
  #script3="${remoteDir}/waspass"
  script3="${remoteDir}/installSignerCerts.py"
}

while getopts ":osh:m:l:i:" opt; do
   case $opt in
      h) listOfServers=$(echo "${OPTARG}" | tr A-Z a-z);;
      m) mui=$(echo "${OPTARG}" | tr A-Z a-z);;
      l) inLogFile=$(echo "${OPTARG}");;
      i) inFile=$(echo "${OPTARG}");;
      *) echo "Invalid option: "${OPTARG}""
         Usage 20;;
   esac
done

toolSetType=installSignerCerts

# this is the dir on the target server where we will place things
remoteDir1=/home/wsuser/webapp/work/$toolSetType
remoteDir2=/wastmp/work/$toolSetType
setRemoteDirectory $remoteDir1

runScript1=
runScript2=
script3=
script4=

createdInFile=

# These are the only 2 valid working dir for this script ...
pushIdWorkingDir=/home/wsuser/webapp/work/$toolSetType
pushIdWorkingDirTEST=/home/wsuser/webapp/work/whickey/py_stuff/${toolSetType}-TEST
PWD=$(pwd)
if [[ "$PWD" != "$pushIdWorkingDir" && "$PWD" != "$pushIdWorkingDirTEST" ]]; then
  PWD=$pushIdWorkingDir
fi
# this is the dir on the mgtp* server where the scripts we are kept
listOfLogFiles= # This will be used at the end when we 'grep' through them looking for SUCCESS and ERROR messages
localDirBin=$PWD/bin

timeStamp=$(date +%m%d%y-%H%M%S)

# a temp file to dump output to ...
tempLogFile=$PWD/logs/${toolSetType}-TEMP-${timeStamp}.log
echo START > $tempLogFile

#if [ -z "$inFile" ]; then
#  echo ERROR: The use of the -i <input file> is required.
#  Usage 22
#fi

if [ ! -z "$inFile" ]; then
  if [ ! -f "$inFile" ]; then
     echo ERROR: got input file parameter[$inFile] but can not find this file.
     Usage 22
  fi
else
  if [[ -z "$listOfServers" || -z "$mui" ]]; then
    echo ERROR: If the input file parameter is not used then both the -h and -m are required
    Usage 22
  else
    inputFilesDir=${PWD}/inputFiles/
    if [ ! -d "$inputFilesDir" ]; then
      mkdir -p $inputFilesDir
    fi
    inFile=${inputFilesDir}/inputFile-TEMP-${timeStamp}.txt
    echo HOSTS=${listOfServers} ENV=${mui} > $inFile
    createdInFile=1
  fi 
fi

inLines=$(cat "${inFile}" | grep -v ^# | tr ' ' '&' | tr '\n' '^')
for inLine in $(echo $inLines|tr '^' ' '); do
  listOfServers=
  mui=
  logFile=
  if [ ! -z "$inLogFile" ]; then
    logFile=$inLogFile
  fi

  listOfServers=$(echo $inLine | tr '&' '\n' | grep HOSTS= | awk -F= {'print $2'})
  mui=$(echo $inLine | tr '&' '\n' | grep ENV= | awk -F= {'print $2'})

  if [ -z "$listOfServers" ]; then
    echo ERROR: The list of host names needed be passed in either by input parameter -h or by the input file HOSTS=
    Usage 22
  fi
  if [ -z "$mui" ]; then
    echo ERROR: The WAS environment needs be passed in either by input parameter -m or by the input file MUI=
    Usage 22
  fi

  listOfServersForLogFileName=$(echo $listOfServers | tr ',' '-')

  if [ -z "$logFile" ]; then
    if [ -z "$mui" ]; then
      logFile=$PWD/logs/${toolSetType}-ALL-$listOfServersForLogFileName-${timeStamp}.log
    else
      logFile=$PWD/logs/${toolSetType}-${mui}-$listOfServersForLogFileName-${timeStamp}.log
    fi
  fi
  # add it to the list
  listOfLogFiles="$listOfLogFiles $logFile"

  echo START listOfServers[$listOfServers]env[$mui]inputFile[$inFile]logFile[$logFile]
  echo START listOfServers[$listOfServers]env[$mui]inputFile[$inFile]logFile[$logFile] >> $logFile

  for serverName in $(echo $listOfServers | tr ',' '\n'); do
    pushFilesToServer= # reset this each time when we start with a new host name.
    found60env=
    echo ++++++++++++++++ WORKING on serverName[$serverName] >> $logFile
    echo ++++++++++++++++ WORKING on serverName[$serverName]

    pingTest=$(ping -c 1 $serverName | grep "bytes from" 2>&1)
    if [ -z "$pingTest" ]; then
      echo [$serverName]ERROR ping test failed for serverName[$serverName] >> $logFile
      echo [$serverName]ERROR ping test failed for serverName[$serverName]
      continue
    fi
    echo PING test to[$serverName] successful with[$pingTest]

    sshTestGOOD=$(ssh -o NumberOfPasswordPrompts=0 -o ConnectTimeout=1 wsuser\@$serverName uptime|grep "load average" 2>&1)
    if [ -z "$sshTestGOOD" ]; then
      echo [$serverName]ERROR ssh test failed for serverName[$serverName] as we were ask for a password >> $logFile
      echo [$serverName]ERROR ssh test failed for serverName[$serverName] as we were ask for a password
      continue
    fi
    echo SSH test to[$serverName] successful with[$sshTestGOOD]

    ### Get all the .profile_* file names that have the string WAS_DM_HOME in them ... except for the .profile_50
    for profileEnv in $(ssh wsuser\@$serverName grep -l -e WAS_DM_HOME -e IHS_HOME .profile_* | grep -v 50); do
      isWASprofile=$(ssh wsuser\@$serverName grep WAS_DM_HOME $profileEnv)
      isIHSprofile=$(ssh wsuser\@$serverName grep IHS_HOME $profileEnv)
      profileEnvValue=$(echo $profileEnv | awk -F'profile_' {'print $2'})

#skipEnv=$(echo $profileEnvValue|grep prd)
#if [ ! -z "$skipEnv" ]; then
#echo SKIPPING production environment[$profileEnvValue] for now, see william_hickey@optum.com about this. 
#echo SKIPPING production environment[$profileEnvValue] for now, see william_hickey@optum.com about this. >> $logFile
#continue
#fi

      if [ ! -z "$mui" ]; then
        usingMUI=$(echo $profileEnvValue|grep $mui)
        if [ -z "$usingMUI" ]; then
          echo SKIPPING environment[$profileEnvValue]
          echo SKIPPING environment[$profileEnvValue] >> $logFile
          continue
        fi
      fi

      echo Found PROFILE profileEnv[$profileEnv]profileEnvValue[$profileEnvValue] >> $logFile
      echo Found PROFILE profileEnv[$profileEnv]profileEnvValue[$profileEnvValue]

      found60env=$(echo $profileEnvValue | grep -e ...60... -e ...61...)

      ### IF we have not, setup a remote dir location to place these script that we are going to run, and push them out.
      if [ -z "$pushFilesToServer" ]; then
        pushFilesToServer=1
        setRemoteDirectory $remoteDir1
        mkdirOutput=$(ssh wsuser\@$serverName mkdir -p $remoteDir 2>&1)
#        scpErrors=$(scp ${localDirBin}/* $serverName:$remoteDir 2>&1 | grep -e "No space left on device" -e "No such file" -e "not found")
# rsync --archive --verbose --rsh=ssh /ebiz_automation/ebizsrc/was/85/repository/os_all webrs0308:/ebiz_iim/ebizsrc/IBM/WAS/repository
        scpErrors=$(rsync --archive --rsh=ssh ${localDirBin}/ $serverName:$remoteDir 2>&1 | grep -e "No space left on device" -e "No such file" -e "not found")
        
        if [ ! -z "$scpErrors" ]; then
          setRemoteDirectory $remoteDir2
          ssh wsuser\@$serverName mkdir -p $remoteDir
#          scpErrors=$(scp ${localDirBin}/* $serverName:$remoteDir 2>&1 | grep -e "No space left on device" -e "No such file" -e "not found")
          scpErrors=$(rsync --archive --rsh=ssh ${localDirBin}/ $serverName:$remoteDir 2>&1 | grep -e "No space left on device" -e "No such file" -e "not found")
          if [ ! -z "$scpErrors" ]; then
            echo ERROR: scp of files to the host[$serverName] returned errors 'No space left on device' for scp of files to both remote directories[$remoteDir1][$remoteDir2]. Clean up some room on one of these directories and try again.]
            continue
          fi
        fi
        echo $scpOutput >> $logFile
      fi

      foundError= # clean any errors we may have found before ...
      scriptToRun=$runScript1
      cmdToRun="$runScript1 $profileEnvValue ${remoteDir1}/certs $script3"
      runScriptNOTfound=$(ssh wsuser\@$serverName ls $scriptToRun 2>&1 | egrep "No such file"\|"not found")
#echo TEST runScriptNOTfound[$runScriptNOTfound]
      if [ ! -z "$runScriptNOTfound" ]; then
        echo [$serverName][$profileEnvValue]ERROR: file[$scriptToRun] NOT found on server[$serverName]
        echo [$serverName][$profileEnvValue]ERROR: file[$scriptToRun] NOT found on server[$serverName] >> $logFile
        exit 22
      fi

      echo Running[ssh $serverName $cmdToRun]
      echo Running[ssh $serverName $cmdToRun] >> $logFile
      ssh wsuser\@$serverName $cmdToRun 2>&1 > $tempLogFile
      cat $tempLogFile >> $logFile
      foundError=$(grep -e Exception -e ERROR -e WARNING $tempLogFile) 

# Testing ...
#continue

      if [ -z "$foundError" ]; then
        messages=$(grep "SUCCESS" $tempLogFile)
        if [ ! -z "$messages" ]; then
          echo [$serverName][$profileEnvValue]SUCCESS installing signer cert[$messages]
          echo [$serverName][$profileEnvValue]SUCCESS installing signer cert[$messages] >> $logFile
        fi
#        messages=$(grep "SKIPPING" $tempLogFile)
#        if [ ! -z "$messages" ]; then
#          echo [$serverName][$profileEnvValue]SKIPPING pushing new id/pw to WAS Admin Console[$messages]
#          echo [$serverName][$profileEnvValue]SKIPPING pushing new id/pw to WAS Admin Console[$messages] >> $logFile
#        fi
      else  # IF we found an error ... 
        foundSpecificNodeError=$(echo $foundError | grep "Access is denied for the sync operation" )
        foundSpecificAuthError=$(echo $foundError | grep "Access is denied for the getProcessType operation" )
        if [ ! -z "$foundSpecificNodeError" ]; then
          lastNodeSynced=$(grep "INFO START synchronizing node" $tempLogFile | tail -1)
          echo [$serverName][$profileEnvValue]ERROR Access is denied found during syncNode operation on NODE[$lastNodeSynced], try bouncing the whole WAS environment and running this script again.
          echo [$serverName][$profileEnvValue]ERROR Access is denied found during syncNode operation on NODE[$lastNodeSynced], try bouncing the whole WAS environment and running this script again. >> $logFile
        elif [ ! -z "$foundSpecificAuthError" ]; then
         echo [$serverName][$profileEnvValue]ERROR Access is denied running script, try bouncing the whole WAS environment and running this script again.
          echo [$serverName][$profileEnvValue]ERROR Access is denied running script, try bouncing the whole WAS environment and running this script again. >> $logFile
        else
          echo [$serverName][$profileEnvValue]ERROR found[$foundError]
          echo [$serverName][$profileEnvValue]ERROR found[$foundError] >> $logFile
        fi
      fi
    done # Env of list of found envs loop

    if [ -z "$found60env" ]; then
      # clean up the scripts we pushed to the target servers.
      echo Running[ssh $serverName rm -fr $remoteDir] >> $logFile
      echo Running[ssh $serverName rm -fr $remoteDir]
      ssh wsuser\@$serverName rm -fr $remoteDir 2>&1 >> $logFile
    else
      echo INFO:we will leave the remote dir content[${serverName}:${remoteDir}] for use of the found WAS6x environment
      echo INFO:we will leave the remote dir content[${serverName}:${remoteDir}] for use of the found WAS6x environment >> $logFile
    fi
  done # End of listOfServers loop
done # End of infile loop

rm -f $tempLogFile
if [ ! -z "$createdInFile" ]; then
  echo INFO removing input file[$inFile]
  rm -f $inFile
fi

echo SUMMARY: This is a list of SUCCESS and ERROR messages that have occurred.
echo ==================== SUCCESSES ==========================================
grep -h ]SUCCESS ${listOfLogFiles} | grep -v ====== | grep -v SUMMARY
echo ==================== ERRORS =============================================
grep -h ]ERROR ${listOfLogFiles} | grep -v ====== | grep -v SUMMARY
echo ==================== SKIPS ==============================================
grep -h SKIPPING ${listOfLogFiles} | grep -v ====== | grep -v SUMMARY
echo ==================== INFO ===============================================
grep -h INFO ${listOfLogFiles} | grep -v ====== | grep -v SUMMARY
echo =========================================================================




#!/bin/bash



for i in `cat inputFiles/copyCert.input`
do

        HOST=`echo $i | awk -F, '{print $1}'`
        VERSION=`echo $i | awk -F, '{print $2}'`


        login=`ssh -o PasswordAuthentication=no $HOST pwd exit`


        if [[ "$login" = /home/wsuser ]]
        then


                       echo "Working on .....$HOST "
		       scp  /ebiz/work/installSignerCerts/bin/certs/OptumRootCA.cer $HOST:/tmp/OptumRootCA.cer >/dev/null 2>&1
		       scp  /ebiz/work/installSignerCerts/bin/certs/OptumIssuingCA.cer $HOST:/tmp/OptumIssuingCA.cer >/dev/null 2>&1
		       scp  /ebiz/work/installSignerCerts/bin/certs/OptumIssuingCA2.cer $HOST:/tmp/OptumIssuingCA2.cer >/dev/null 2>&1

         else
           echo "$HOST,NON_REACHABLE" >> copyCert.log
        fi


done 2>/dev/null

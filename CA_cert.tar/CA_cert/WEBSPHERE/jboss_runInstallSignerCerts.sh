#!/bin/bash



for i in `cat inputFiles/jboss.input`
do

        HOST=`echo $i | awk -F, '{print $1}'`
        VERSION=`echo $i | awk -F, '{print $2}'`


        login=`ssh -o PasswordAuthentication=no $HOST pwd exit`


        if [[ "$login" = /home/wsuser ]]
        then


                   if [[ $VERSION = EAP6 ]]
                   then
                       echo "Working on EAP6.....$HOST "
		       scp  /ebiz/work/installSignerCerts/bin/certs/OptumRootCA.cer $HOST:/wastmp/OptumRootCA.cer >/dev/null 2>&1
		       scp  /ebiz/work/installSignerCerts/bin/certs/OptumIssuingCA.cer $HOST:/wastmp/OptumIssuingCA.cer >/dev/null 2>&1
		       scp  /ebiz/work/installSignerCerts/bin/certs/OptumIssuingCA2.cer $HOST:/wastmp/OptumIssuingCA2.cer >/dev/null 2>&1
                       scp  /ebiz/work/installSignerCerts/bin/EAP_runinstall.sh $HOST:/wastmp/EAP_runinstall.sh  >/dev/null 2>&1
                       ssh $HOST " chmod 750 /wastmp/EAP_runinstall.sh ; /wastmp/EAP_runinstall.sh ; rm -f /wastmp/EAP_runinstall.sh " >> jboss_certs.log 2>/dev/null
                    else
                       echo "Working on EAP64........$HOST "
		       scp  /ebiz/work/installSignerCerts/bin/certs/OptumRootCA.cer $HOST:/wastmp/OptumRootCA.cer >/dev/null 2>&1
                       scp  /ebiz/work/installSignerCerts/bin/certs/OptumIssuingCA.cer $HOST:/wastmp/OptumIssuingCA.cer >/dev/null 2>&1
                       scp  /ebiz/work/installSignerCerts/bin/certs/OptumIssuingCA2.cer $HOST:/wastmp/OptumIssuingCA2.cer >/dev/null 2>&1
                       scp  /ebiz/work/installSignerCerts/bin/EAP64_runinstall.sh $HOST:/wastmp/EAP64_runinstall.sh >/dev/null 2>&1
                       ssh $HOST "chmod 750 /wastmp/EAP64_runinstall.sh ; /wastmp/EAP64_runinstall.sh ; rm -f /wastmp/EAP_runinstall.sh" >> jboss_certs.log 2>/dev/null
                   fi

         else
           echo "$HOST,NON_REACHABLE" >> jboss_certs.log
        fi


done 2>/dev/null

#! /bin/ksh
MUI=$1
WASVERSION=$2
ENV=$3
while read p; do
echo "HOSTS=$p ENV=$1$2$3" >> /ebiz/work/installSignerCerts/cert.input
done </ebiz/work/installSignerCerts/server1.txt

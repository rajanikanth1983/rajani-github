#!/bin/bash
echo "inside install"

HOSTNAME=`hostname`
multiple_certstore=$( (find /ebiz/*/java ; find /ebiz/*/jboss-eap* ; find /ebiz/install/jdk* ; find /ebiz/java/latest/) | grep cacerts$)
key_tool=$( (find /ebiz/*/java ; find /ebiz/*/jboss-eap* ; find /ebiz/install/jdk* ; find /ebiz/java/latest/) | grep jre/bin/keytool$ | head -1)



if [ -z "$multiple_certstore" ]; then
   echo "$HOSTNAME,No Keystore found,ADD SIGNER FAILED"
exit
fi

if [ -z "$key_tool" ]; then
   echo "$HOSTNAME,No Keytool found,ADD SIGNER FAILED"
exit
fi

for certstore in $(echo $multiple_certstore)
do

   cp $certstore $certstore.backup.`date +%F_%R`
done

for certstore in $(echo $multiple_certstore)
do

   $key_tool -list -keystore $certstore -alias OptumInternalIssuingCA2_2022 -storepass changeit 2>&1| grep "does not exist" >/dev/null 2>&1

    if [[ $? = 0 ]]
    then

        $key_tool -import -keystore $certstore -file /ebiz/dumps/OptumInternalIssuingCA2_2022.crt -alias OptumInternalIssuingCA2_2022  -storepass changeit -noprompt >/dev/null 2>&1
        if [[ $? = 0 ]]
        then
           echo "$HOSTNAME,$certstore,ADD SIGNER SUCCESS"
        else
           echo "$HOSTNAME,$certstore,ADD SIGNER FAILED"
        fi
    else
        echo "$HOSTNAME,$certstore,SIGNER ALREADY EXISTS SKIPPING"
    fi


   $key_tool -list -keystore $certstore -alias OptumInternalPolicyCA_2022  -storepass changeit 2>&1| grep "does not exist" >/dev/null 2>&1

    if [[ $? = 0 ]]
    then

        $key_tool -import -keystore $certstore -file /ebiz/dumps/OptumInternalPolicyCA_2022.crt -alias OptumInternalPolicyCA_2022 -storepass changeit -noprompt >/dev/null 2>&1
        if [[ $? = 0 ]]
        then
           echo "$HOSTNAME,$certstore,ADD SIGNER SUCCESS"
        else
           echo "$HOSTNAME,$certstore,ADD SIGNER FAILED"
        fi
    else
        echo "$HOSTNAME,$certstore,SIGNER ALREADY EXISTS SKIPPING"
    fi

   $key_tool -list -keystore $certstore -alias ca4_Optum_Root_CA3 -storepass changeit 2>&1| grep "does not exist" >/dev/null 2>&1

    if [[ $? = 0 ]]
    then

        $key_tool -import -keystore $certstore -file /ebiz/dumps/ca4_Optum_Root_CA3.cer -alias ca4_Optum_Root_CA3.cer -storepass changeit -noprompt >/dev/null 2>&1
        if [[ $? = 0 ]]
        then
           echo "$HOSTNAME,$certstore,ADD SIGNER SUCCESS"
        else
           echo "$HOSTNAME,$certstore,ADD SIGNER FAILED"
        fi
    else
        echo "$HOSTNAME,$certstore,SIGNER ALREADY EXISTS SKIPPING"
    fi
   $key_tool -list -keystore $certstore -alias ca4_Optum_Policy_CA3  -storepass changeit 2>&1| grep "does not exist" >/dev/null 2>&1

    if [[ $? = 0 ]]
    then

        $key_tool -import -keystore $certstore -file /ebiz/dumps/ca4_Optum_Policy_CA3.cer -alias ca4_Optum_Policy_CA3 -storepass changeit -noprompt >/dev/null 2>&1
        if [[ $? = 0 ]]
        then
           echo "$HOSTNAME,$certstore,ADD SIGNER SUCCESS"
        else
           echo "$HOSTNAME,$certstore,ADD SIGNER FAILED"
        fi
    else
        echo "$HOSTNAME,$certstore,SIGNER ALREADY EXISTS SKIPPING"
    fi
   $key_tool -list -keystore $certstore -alias ca4_Optum_Issuing_CA4  -storepass changeit 2>&1| grep "does not exist" >/dev/null 2>&1

    if [[ $? = 0 ]]
    then

        $key_tool -import -keystore $certstore -file /ebiz/dumps/ca4_Optum_Issuing_CA4.cer -alias ca4_Optum_Issuing_CA4 -storepass changeit -noprompt >/dev/null 2>&1
        if [[ $? = 0 ]]
        then
           echo "$HOSTNAME,$certstore,ADD SIGNER SUCCESS"
        else
           echo "$HOSTNAME,$certstore,ADD SIGNER FAILED"
        fi
    else
        echo "$HOSTNAME,$certstore,SIGNER ALREADY EXISTS SKIPPING"
    fi
   $key_tool -list -keystore $certstore -alias Optum_Internal_Issuing_CA3_2023  -storepass changeit 2>&1| grep "does not exist" >/dev/null 2>&1

    if [[ $? = 0 ]]
    then

        $key_tool -import -keystore $certstore -file /ebiz/dumps/Optum_Internal_Issuing_CA3_2023.crt -alias Optum_Internal_Issuing_CA3_2023 -storepass changeit -noprompt >/dev/null 2>&1
        if [[ $? = 0 ]]
        then
           echo "$HOSTNAME,$certstore,ADD SIGNER SUCCESS"
        else
           echo "$HOSTNAME,$certstore,ADD SIGNER FAILED"
        fi
    else
        echo "$HOSTNAME,$certstore,SIGNER ALREADY EXISTS SKIPPING"
    fi
done

rm -f /wastmp/OptumInternalIssuingCA2_2022.crt
rm -f /wastmp/OptumInternalPolicyCA_2022.crt
rm -f /wastmp/Optum_Internal_Issuing_CA3_2023.crt
rm -f /wastmp/ca4_Optum_Issuing_CA4.cer
rm -f /wastmp/ca4_Optum_Policy_CA3.cer
rm -f /wastmp/ca4_Optum_Root_CA3.cer

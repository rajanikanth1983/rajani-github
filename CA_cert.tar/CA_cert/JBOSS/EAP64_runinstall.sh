#!/bin/bash

echo "Step 1"
HOSTNAME=`hostname`
multiple_certstore=$( (find /ebiz/*/java; find /ebiz/*/install ; find /ebiz/install/jdk* ; find /ebiz/*/jboss-eap* ; find /ebiz/java/latest/) | grep cacerts$)
key_tool=$( (find /ebiz/*/java; find /ebiz/*/install ; find /ebiz/install/jdk* ; find /ebiz/*/jboss-eap* ; find /ebiz/java/latest/) | grep jre/bin/keytool$ | head -1)

echo "$multiple_certstore"

if [ -z "$multiple_certstore" ]; then
   echo "$HOSTNAME,No Keystore found,ADD SIGNER FAILED"
exit
fi

if [ -z "$key_tool" ]; then
   echo "$HOSTNAME,No Keytool found,ADD SIGNER FAILED"
exit
fi

for certstore in $(echo $multiple_certstore)
do

   cp $certstore $certstore.backup.`date +%F_%R`
done



for certstore in $(echo $multiple_certstore)
do
   
   $key_tool -list -keystore $certstore -alias OptumInternalIssuingCA2_2022 -storepass changeit 2>&1| grep "does not exist" >/dev/null 2>&1

    if [[ $? = 0 ]]
    then
        $key_tool -import -keystore $certstore -file /wastmp/OptumInternalIssuingCA2_2022.crt -alias OptumInternalIssuingCA2_2022  -storepass changeit -noprompt >/dev/null 2>&1
        if [[ $? = 0 ]]
        then
           echo "$HOSTNAME,$certstore,ADD SIGNER SUCCESS"
        else
           echo "$HOSTNAME,$certstore,ADD SIGNER FAILED"
        fi
    else
        echo "$HOSTNAME,$certstore,SIGNER ALREADY EXISTS SKIPPING"
    fi


   $key_tool -list -keystore $certstore -alias OptumInternalPolicyCA_2022  -storepass changeit 2>&1| grep "does not exist" >/dev/null 2>&1

    if [[ $? = 0 ]]
    then

        $key_tool -import -keystore $certstore -file /wastmp/OptumInternalPolicyCA_2022.crt -alias OptumInternalPolicyCA_2022 -storepass changeit -noprompt >/dev/null 2>&1
        if [[ $? = 0 ]]
        then
           echo "$HOSTNAME,$certstore,ADD SIGNER SUCCESS"
        else
           echo "$HOSTNAME,$certstore,ADD SIGNER FAILED"
        fi
    else
        echo "$HOSTNAME,$certstore,SIGNER ALREADY EXISTS SKIPPING"
    fi

done
  
rm -f /wastmp/OptumInternalIssuingCA2_2022.crt
rm -f /wastmp/OptumInternalPolicyCA_2022.crt
#rm -f /wastmp/Comodo_Intermediate_Client_Email.cer
#rm -f /wastmp/sectigo_codesign.cer
#rm -f /wastmp/sectigo_intermediate.cer
#rm -f /wastmp/usertrust_root.cer


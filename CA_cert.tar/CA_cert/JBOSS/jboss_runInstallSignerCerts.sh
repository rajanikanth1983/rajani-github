#!/bin/bash


for i in `cat inputFiles/jboss.input`
do

        HOST=`echo $i | awk -F, '{print $1}'`
        VERSION=`echo $i | awk -F, '{print $2}'`


        login=`ssh -o PasswordAuthentication=no $HOST pwd exit`

        echo $login
        if [[ "$login" = /home/wsuser ]]
        then


                 #  if [[ $VERSION = EAP6 ]]
                 #  then
                  #     echo "Working on this EAP6 server.....$HOST "
                   #    scp  /home/wsuser/webapp/work/rchippa1/COMODO_Signers/JBOSS/CERTS/OptumInternalIssuingCA2_2022.crt $HOST:/wastmp/OptumInternalIssuingCA2_2022.crt >/dev/null 2>&1
                    #   scp  /home/wsuser/webapp/work/rchippa1/COMODO_Signers/JBOSS/CERTS/OptumInternalPolicyCA_2022.crt $HOST:/wastmp/OptumInternalPolicyCA_2022.crt >/dev/null 2>&1
                     #  scp  /home/wsuser/webapp/work/rchippa1/COMODO_Signers/JBOSS/CERTS/Optum_Internal_Issuing_CA3_2023.crt $HOST:/wastmp/Optum_Internal_Issuing_CA3_2023.crt >/dev/null 2>&1
                      # scp  /home/wsuser/webapp/work/rchippa1/COMODO_Signers/JBOSS/CERTS/ca4_Optum_Root_CA3.cer $HOST:/wastmp/ca4_Optum_Root_CA3.cer >/dev/null 2>&1
                      # scp  /home/wsuser/webapp/work/rchippa1/COMODO_Signers/JBOSS/CERTS/ca4_Optum_Issuing_CA4.cer $HOST:/wastmp/ca4_Optum_Issuing_CA4.cer >/dev/null 2>&1
                       #scp  /home/wsuser/webapp/work/rchippa1/COMODO_Signers/JBOSS/CERTS/ca4_Optum_Policy_CA3.cer $HOST:/wastmp/ca4_Optum_Policy_CA3.cer  >/dev/null 2>&1
                       #scp  /home/wsuser/webapp/work/rchippa1/COMODO_Signers/JBOSS/EAP_runinstall.sh $HOST:/wastmp/EAP_runinstall.sh  >/dev/null 2>&1
                       #ssh $HOST " chmod 750 /wastmp/EAP_runinstall.sh ; /wastmp/EAP_runinstall.sh ; rm -f /wastmp/EAP_runinstall.sh ; rm -f /wastmp/*.cer " 

                  # else
                       echo "Working on this EAP6 server.....$HOST "
                       scp  /home/wsuser/webapp/work/rchippa1/COMODO_Signers/JBOSS/CERTS/OptumInternalIssuingCA2_2022.crt $HOST:/ebiz/dumps/OptumInternalIssuingCA2_2022.crt >/dev/null 2>&1
                       scp  /home/wsuser/webapp/work/rchippa1/COMODO_Signers/JBOSS/CERTS/OptumInternalPolicyCA_2022.crt $HOST:/ebiz/dumps/OptumInternalPolicyCA_2022.crt >/dev/null 2>&1
                       scp  /home/wsuser/webapp/work/rchippa1/COMODO_Signers/JBOSS/CERTS/Optum_Internal_Issuing_CA3_2023.crt $HOST:/ebiz/dumps/Optum_Internal_Issuing_CA3_2023.crt >/dev/null 2
>&1
                       scp  /home/wsuser/webapp/work/rchippa1/COMODO_Signers/JBOSS/CERTS/ca4_Optum_Root_CA3.cer $HOST:/ebiz/dumps/ca4_Optum_Root_CA3.cer >/dev/null 2>&1
                       scp  /home/wsuser/webapp/work/rchippa1/COMODO_Signers/JBOSS/CERTS/ca4_Optum_Issuing_CA4.cer $HOST:/ebiz/dumps/ca4_Optum_Issuing_CA4.cer >/dev/null 2>&1
                       scp  /home/wsuser/webapp/work/rchippa1/COMODO_Signers/JBOSS/CERTS/ca4_Optum_Policy_CA3.cer $HOST:/ebiz/dumps/ca4_Optum_Policy_CA3.cer  >/dev/null 2>&1
                       scp  /home/wsuser/webapp/work/rchippa1/COMODO_Signers/JBOSS/EAP_runinstall.sh $HOST:/ebiz/dumps/EAP_runinstall.sh  >/dev/null 2>&1
                       ssh $HOST " chmod 750 /ebiz/dumps/EAP_runinstall.sh ; /ebiz/dumps/EAP_runinstall.sh ; rm -f /ebiz/dumps/EAP_runinstall.sh ; rm -f /ebiz/dumps/*.cer "
                       echo "after install"
                  # fi

         else
           echo "$HOST,NON_REACHABLE"  
        fi


done 2>/dev/null

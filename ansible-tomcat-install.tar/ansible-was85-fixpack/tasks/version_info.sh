-  name: "Websphere version info"
   shell: "{{ home }}/{{ mui }}/WebSphere{{ 85 }}{{ env }}/Common/bin/versionInfo.sh"
   register: status1

-  debug: var=status1.stdout_lines

-  name: " IHS version info"
   shell: "{{ home }}/{{ mui }}/IHS{{ 85 }}{{ env }}/bin/versionInfo.sh -ifixes"
   register: status1

-  debug: var=status1.stdout_lines

-  name: " Plugin version info"
   shell: "{{ home }}/{{ mui }}/PLG{{ 85 }}{{ env }}/bin/versionInfo.sh -ifixes"
   register: status1

-  debug: var=status1.stdout_lines

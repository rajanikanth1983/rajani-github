ansible-tomcat-install
=========
This Role is used to install Apache Tomcat on a server.

Requirements
------------

    Requires wsuser access (on the remote machine).
    wsuser must be added to cron.
    crontab must be restarted after wsuser added.

    Requires the following directories and disks:
      /ebiz 
      /ebiz/app_logs
      /ebiz/dumps
      /wastmp


Role Variables
--------------

The most common to alter:

    tomcat_version: "9.0.53"
    java_version: "1.8.302"
    environment_level: "prd"

A List of all variables:

    # application versioning
    tomcat_version: "9.0.53"
    java_version: "1.8.302"

    # home dirs
    ansible_binaries_home: "/apps/ansible/binaries"
    java_home: "/ebiz/java"
    tomcat_home: "/ebiz/tomcat"
    tomcat_logs_home: "/ebiz/app_logs/tomcat"
    tomcat_bin: "{{ tomcat_home }}/latest/bin"
    tomcat_conf: "{{ tomcat_home }}/latest/conf"
    user_home: "/home/wsuser"
    user_script_home: "{{ user_home }}/webapp/scripts"
    input_home: "{{ user_home }}/webapp/input"

    # envrionment variables
    environment_level: "prd"

    # output variables
    tomcat-start-output: ""

Dependencies
------------

This ansible role has the following dependencies be available at {{ ansible_binaries_home }}/tomcat:

    log_archive.input
    logging.properties
    .profile_tomcat
    setenv.sh
    tc_health.input
    tomcat_AS.input
    tomcat_JVM.input
    tomcat binary, e.g. apache-tomcat-9.0.53.tar.gz

This ansible role has the following dependencies be available at {{ ansible_binaries_home }}/java/tomcat

    tzdb.dat
    java binary, e.g. java-1.8.302.tar

Example Playbook Contents
----------------


Here is an example playbook which will simply call the playbook with its defaults

    name: Call tomcat install role
      hosts: all
      gather_facts: no
      become: false
      tasks:

      - include_role:
          name: ansible-tomcat-install

Example Playbook Usage
----------------
Standard Install

    ansible-playbook -i /path/to/inventory ./tomcat_install.yml

Install with tomcat_version: "9.0.48", java_version: "1.8.249", and development environment

    ansible-playbook -i /path/to/inventory ./tomcat_install.yml --extra-vars "tomcat_version=9.0.48 java_version=1.8.249 environment_level=dev"

If you install with additional binaries, it is important they are available from the {{ ansible_binaries_home }} or its subdirectories


License
-------

BSD

Author Information
------------------

    Optum Rx WebHosting Team
    Email:  ORx-Webhosting
    ServiceNow: ORX IT WebHosting
